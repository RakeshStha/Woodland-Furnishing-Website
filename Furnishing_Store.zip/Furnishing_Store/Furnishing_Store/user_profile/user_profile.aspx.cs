﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

namespace Furnishing_Store.user_profile
{
    public partial class user : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"]  != null && Session["password"] !=null)
            {
                string  user = Session["username"].ToString();
                string pass= Session["password"].ToString();
                lbl_username.Text = user;
                lbl_password.Text = pass;
                string constr = ConfigurationManager.ConnectionStrings["Furnishing_Store"].ConnectionString;
                SqlConnection con = new SqlConnection(constr);
                SqlCommand cmd = new SqlCommand("select * from signup ", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

               // GridView1.DataSource = reader;
                //GridView1.DataBind();
                con.Close();


            }

        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            Response.Redirect("../login.aspx");
        }

        
    }
}