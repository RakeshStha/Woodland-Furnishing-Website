﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

namespace Furnishing_Store.admin_profile
{
    public partial class add_product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            if (name.Value != "" && color.Value != "" && description.Value != "" && material.Value != "" 
                && dimension.Value != "" && price.Value != "" && type.Value != ""
                && manufacture_country.Value != "" && warranty.Value != "")
            {

                string constr = ConfigurationManager.ConnectionStrings["Furnishing_Store"].ConnectionString;
                SqlConnection con = new SqlConnection(constr);


                string names = name.Value;
                string col = color.Value;
                string desc = description.Value;
                string mat = material.Value;
                string dem = dimension.Value;
                string pri = price.Value;
                string ty = type.Value;
                string manu = manufacture_country.Value;
                string war = warranty.Value;


                SqlCommand cmd = new SqlCommand("insert into product values(@name, @color, @description, @material, @dimension, @price, @type, @manufacture_country, @warranty)", con);
                cmd.Parameters.AddWithValue("@name", names);
                cmd.Parameters.AddWithValue("@color", col);
                cmd.Parameters.AddWithValue("@description", desc);
                cmd.Parameters.AddWithValue("@material", mat);
                cmd.Parameters.AddWithValue("@dimension", dem);
                cmd.Parameters.AddWithValue("@price", pri);
                cmd.Parameters.AddWithValue("@type", ty);
                cmd.Parameters.AddWithValue("@manufacture_country", manu);
                cmd.Parameters.AddWithValue("@warranty", war);


                con.Open();
                cmd.ExecuteScalar();

                con.Close();


                correct.Visible = true;

            }
            else
            {
                Response.Redirect("add_product.aspx");

            }
        }
    }
}