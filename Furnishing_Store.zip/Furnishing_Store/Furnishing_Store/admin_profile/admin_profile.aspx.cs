﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

namespace Furnishing_Store.admin_profile
{
    public partial class admin_profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["Furnishing_Store"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand product = new SqlCommand("select product_id, name, color, description, material,dimension,price,type,manufacture_country,warranty from product", con);
            

            con.Open();
            SqlDataReader rdr = product.ExecuteReader();
            GridView1.DataSource = rdr;
            GridView1.DataBind();
            
            con.Close();
            
            SqlCommand user = new SqlCommand("select user_id, email, phone from signup", con);
            con.Open();
            SqlDataReader rdr2 = user.ExecuteReader();
            GridView2.DataSource = rdr2;
            GridView2.DataBind();
            con.Close();
        }
        protected void View_User(object sender, EventArgs e)
        {

            available_product.Visible = false;
        }
        protected void View_Product(object sender, EventArgs e)
        {

            available_user.Visible = false;
        }







    }
}