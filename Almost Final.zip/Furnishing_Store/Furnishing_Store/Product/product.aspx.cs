﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;
using System.Text;


namespace Furnishing_Store
{
    public partial class user_product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["Furnishing_Store"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand("Select * from product", con);
            SqlDataReader rdr;
            con.Open();
            rdr = cmd.ExecuteReader();

            StringBuilder htmlStr = new StringBuilder("");
            htmlStr.Append("<section class='gallery-block cards-gallery'><div class='container'><div class='row'>");

            while (rdr.Read())
            {
                htmlStr.Append("<div class='col-md-6 col-lg-4' runat='server'  >");
                htmlStr.Append("<div class='border-0 transform-on-hover'>");
                htmlStr.Append("<a href='item_view.aspx?product_id=");
                htmlStr.Append(rdr["product_id"]);
                htmlStr.Append("'>");
                htmlStr.Append("<img src='" + rdr["imagepath"]);
                htmlStr.Append(rdr["imagename"]);

                htmlStr.Append("' width='500'><br> ");
                htmlStr.Append("Name:");
                htmlStr.Append(rdr["name"]);
                htmlStr.Append("Price:");

                htmlStr.Append(rdr["price"]);
                htmlStr.Append("</a>");
                htmlStr.Append("</div>");
                htmlStr.Append("</div></div>");
            }
            htmlStr.Append("</div></div></section>");




            Literal1.Mode = LiteralMode.Encode;
            Literal1.Mode = LiteralMode.PassThrough;
            Literal1.Mode = LiteralMode.Transform;
            Literal1.Text = htmlStr.ToString();
            con.Close();
        }


        protected void Page_Preinit(object sender, EventArgs e)
        {



        }
    }
}